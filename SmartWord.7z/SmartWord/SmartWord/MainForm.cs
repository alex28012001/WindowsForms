﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace SmartWord
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            //Properties.Resources.open.
        }

        private void miOpen_Click(object sender, EventArgs e)
        {
            opfFile.Filter = "TXT FILES|*.txt|DOC|*.doc;*docx|ALL FILES|*.*";
            if (opfFile.ShowDialog() == DialogResult.OK)
            {
                // this.Text = opfFile.FileName;
                for (int i = 0; i < opfFile.FileNames.Length; i++)
                    textBox1.Text += File.ReadAllText(opfFile.FileNames[i], Encoding.Default);
            }
        }

        private void miSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfg = new SaveFileDialog();
          //  sfg.FileName = "mytext.txt";
            if(sfg.ShowDialog() == DialogResult.OK)
            {
                File.WriteAllText(sfg.FileName,textBox1.Text,Encoding.Default);
            }
        }

        private void btnFonts_Click(object sender, EventArgs e)
        {
            FontDialog dialog = new FontDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                textBox1.Font = dialog.Font;
            }
        }

        private void btnColor_Click(object sender, EventArgs e)
        {
            ColorDialog dialog = new ColorDialog();
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                textBox1.ForeColor = dialog.Color;
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbDialog = new FolderBrowserDialog();
            if (fbDialog.ShowDialog() == DialogResult.OK)
            {
                var files = Directory.GetFiles(fbDialog.SelectedPath);
                for (int i = 0; i < files.Length; i++)
                {
                    textBox1.Text += File.ReadAllText(files[i], Encoding.Default);//files[i] + Environment.NewLine;
                }
            }
        }
    }
}
