﻿using MetroFramework.Controls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DemoBackWorker
{
    public partial class MainForm : Form
    {
        BackgroundWorker backWorker;
        public MainForm()
        {
            InitializeComponent();

            pbImage.AllowDrop = true;

            MetroButton mbutton = new MetroButton();
            mbutton.Text = "Button";
            mbutton.Size = new Size(150,20);
            mbutton.Location = new Point(350,50);
            this.Controls.Add(mbutton);


            backWorker = new BackgroundWorker();
            backWorker.DoWork += backWorker_DoWork;
            backWorker.RunWorkerCompleted += backWorker_RunWorkerCompleted;
            backWorker.WorkerReportsProgress = true;
            backWorker.ProgressChanged += backWorker_ProgressChanged;
            backWorker.WorkerSupportsCancellation = true;
        }

        void backWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            lbInfo.Text = String.Format("{0}%", e.ProgressPercentage);
            pbProcess.Value = e.ProgressPercentage;
        }

        void backWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                lbInfo.Text = String.Format("Cancelled ....");
            }
            else
            {
                var date = (DateTime)e.Result;
                lbInfo.Text = String.Format("Completed in {0:HH:mm:ss}", date);
            }
        }

        void backWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            var back = sender as BackgroundWorker;

            int num = (int)e.Argument;

            for (int i =1; i <= num; i++)
            {
                if (backWorker.CancellationPending)
                {
                    back.ReportProgress(0);
                    e.Cancel = true;
                    break;
                }

                back.ReportProgress(i);
                Thread.Sleep(1000);
            }

            e.Result = DateTime.Now;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            pbProcess.Maximum = 10;
            lbInfo.Text = String.Empty;
            if (!backWorker.IsBusy)
               backWorker.RunWorkerAsync(10);
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            backWorker.CancelAsync();
        }

        private void btnShowMessage_Click(object sender, EventArgs e)
        {
            MessageBox.Show(Resourses.Messages.ErrorMessage);
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            List<CultureInfo> cultures = new List<CultureInfo>()
            {
                new CultureInfo("ru"),
                new CultureInfo("en"),
                new CultureInfo("de-DE")
            };

            cbLangs.DisplayMember = "NativeName";
            cbLangs.DataSource = cultures;
            //cbLangs.DataSource = System.Globalization.CultureInfo.GetCultures(CultureTypes.AllCultures);

            this.Location= Properties.Settings.Default.Location;
            this.Size= Properties.Settings.Default.Size;
            var findCult = cultures.Find(p => p.Name.Equals(Properties.Settings.Default.Language));
            cbLangs.SelectedItem = findCult;
           // Thread.CurrentThread.CurrentCulture = findCult;
           // Thread.CurrentThread.CurrentUICulture = findCult;

        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Properties.Settings.Default.Location = this.Location;
            Properties.Settings.Default.Size = this.Size;

            var selLng =   cbLangs.SelectedItem as CultureInfo;
            if (selLng!=null)
              Properties.Settings.Default.Language = selLng.Name;

            Properties.Settings.Default.Save();

        }

        private void cbLangs_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selLng = cbLangs.SelectedItem as CultureInfo;
            if (selLng != null)
            {
                Thread.CurrentThread.CurrentCulture = selLng;
                Thread.CurrentThread.CurrentUICulture = selLng;

                ComponentResourceManager resource = new ComponentResourceManager(typeof(MainForm));

                for (int i = 0; i < this.Controls.Count; i++)
                {
                    resource.ApplyResources(this.Controls[i], this.Controls[i].Name, selLng);
                }

                resource.ApplyResources(miFile, miFile.Name, selLng);
                resource.ApplyResources(miOpen, miOpen.Name, selLng);

            }
        }

        private void pbImage_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Move;
        }

        private void pbImage_DragDrop(object sender, DragEventArgs e)
        {
            var paths= e.Data.GetData(DataFormats.FileDrop) as string[];
            if(paths!=null && paths.Length!=0)
              pbImage.ImageLocation = paths[0];
        }

        private void pbImage_DragLeave(object sender, EventArgs e)
        {

        }
    }
}
